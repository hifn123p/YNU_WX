-------------------
用到的模块有
django .
mysqlclient .


解析：
beautifulsoup4.
lxml.



-------------------
# django test

收藏夹：admin  adminadmin


pip install mysqlclient

1.修改setting 的 database
```
'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'test',
        'USER': 'root',
        'PASSWORD': '3148285',
        'HOST': '118.89.59.29',
        'PORT': 3306
    }
```




-----------------------

    表单里加上{% csrf_token %}

    在Settings里的MIDDLEWARE_CLASSES增加配置：’django.middleware.csrf.CsrfViewMiddleware’；

    在view文件中加入装饰器@csrf_exempt如下：

 from django.views.decorators.csrf import csrf_exempt

 @csrf_exempt 
 def contact(request):

