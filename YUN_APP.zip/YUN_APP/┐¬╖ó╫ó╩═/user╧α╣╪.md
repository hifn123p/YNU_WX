# 页面：user
本地缓存：isbind 绑定判断
         storagesize 缓存大小
         msg 获取授权信息 true成功，false
         hasUserInfo 用户信息

onload：载入app中全局变量->赋值给 userinfo  hasuserinfo
onshow：读取本地缓存大小，设置绑定与未绑定

# 绑定事件：
btnbind 绑定教务系统按键：判断是否登录，是跳转到user_bind界面，否弹出toast提示登录

clean 清楚缓存按键：弹出modal清楚数据

# 相关子页面：
user_bind:绑定页面
user_gy：关于页面


## user_bind:绑定页面
isbind：通过获取本地缓存赋值
loading1：绑定
loading2：解绑

onshow：读取本地缓存isbind

### 绑定事件：
user password获取输入框的值

login：绑定按钮，提交到服务器，返回josn  设置本地缓存
loginout：解绑按钮，删除本地缓存


## user_gy
